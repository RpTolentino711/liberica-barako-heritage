<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin Login — LIBÉRICA Heritage</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/coffee_Liberica_bean.png')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-auth.css')); ?>?v=4">
</head>
<body class="login-body">
    <main class="login-card">
        <div class="login-mark login-brand-mark" aria-hidden="true">
            <img src="<?php echo e(asset('assets/coffee_Liberica_bean.png')); ?>" alt="" width="62" height="62">
        </div>
        <h1>LIBÉRICA</h1>
        <p>Heritage Administration</p>

        <?php if(session('status')): ?>
            <div class="alert-success" role="status"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert-error" role="alert"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.authenticate')); ?>" id="admin-login-form" novalidate>
            <?php echo csrf_field(); ?>
            <label for="email">Email address</label>
            <input
                id="email"
                name="email"
                type="email"
                inputmode="email"
                value="<?php echo e(old('email')); ?>"
                required
                maxlength="254"
                autocomplete="username"
                aria-describedby="email-feedback"
                autofocus
            >
            
            <div class="auth-email-feedback" id="email-feedback" role="status" aria-live="polite"></div>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" required autocomplete="current-password">
            <button class="primary-button" type="submit" id="admin-signin-button">SIGN IN →</button>
        </form>

        <a class="auth-secondary-link" href="<?php echo e(route('admin.password.request')); ?>">Forgot password?</a>
        <a href="<?php echo e(route('home')); ?>">← Back to website</a>
    </main>

    <script>
        (() => {
            'use strict';

            const form = document.getElementById('admin-login-form');
            const email = document.getElementById('email');
            const feedback = document.getElementById('email-feedback');
            const submit = document.getElementById('admin-signin-button');
            const emailPattern = /^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/;
            let attempted = false;

            // Instant, client-side email FORMAT validation; no fetch request or debounce.
            // Actual account and password checks remain in Laravel's authenticate handler.
            function validateEmail() {
                const value = email.value.trim();
                const valid = emailPattern.test(value) && email.checkValidity();

                let error = '';
                if (!value && attempted) {
                    error = 'Please enter your email address.';
                } else if (value && !valid) {
                    error = 'Enter a valid email address (e.g. name@example.com).';
                }

                feedback.textContent = error;
                feedback.classList.toggle('is-error', Boolean(error));
                email.setAttribute('aria-invalid', String(Boolean(error)));
                submit.disabled = !valid;
                return valid;
            }

            email.addEventListener('input', validateEmail);

            form.addEventListener('submit', (event) => {
                attempted = true;
                if (!validateEmail()) {
                    event.preventDefault();
                    email.focus();
                }
            });

            validateEmail();
        })();
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\liberica-barako-heritage-main\resources\views/admin/login.blade.php ENDPATH**/ ?>